# nanaboshi-53833d2 — Remote League

| Opponent | Wins (P1) | Wins (P2) | Wins (Total) | Games | Win Rate % |
|---|---:|---:|---:|---:|---:|
| smarteragent-8660586 | 1 | 0 | 1 | 140 | 0.7 |
| forwardthinkerv4-852bea3 | 1 | 0 | 1 | 200 | 0.5 |
| forward-thinker-rheaagent-6563256 | 0 | 0 | 0 | 240 | 0.0 |
| nanaboshi08270-b40ea88 | 0 | 0 | 0 | 240 | 0.0 |
| team-agent-smith-v3-ce6fd70 | 0 | 0 | 0 | 240 | 0.0 |
| team-agent-smith-v4-24478ed | 0 | 0 | 0 | 240 | 0.0 |
| forward-thinkersv4-852bea3 | 0 | 0 | 0 | 220 | 0.0 |
| team-agent-smithv6-a7b2416 | 0 | 0 | 0 | 220 | 0.0 |
| forward-thinkersv2-51dd50a | 0 | 0 | 0 | 200 | 0.0 |
| nanaboshi08280-c2aa68b | 0 | 0 | 0 | 200 | 0.0 |
| forwardthinkerv4-591a256 | 0 | 0 | 0 | 160 | 0.0 |
| greedy-lookahead-agent-v2-e75e8f5 | 0 | 0 | 0 | 160 | 0.0 |
| nanaboshi08268-54e82c1 | 0 | 0 | 0 | 160 | 0.0 |
| team-agent-smithv5-281cf89 | 0 | 0 | 0 | 160 | 0.0 |
| teamtitansagentv3-4527642 | 0 | 0 | 0 | 160 | 0.0 |
| another-sample-agent-9c1133c | 0 | 0 | 0 | 140 | 0.0 |
| auto-polled-test-9c1133c | 0 | 0 | 0 | 140 | 0.0 |
| galacticarmada-ecd6ae8 | 0 | 0 | 0 | 140 | 0.0 |
| gnn_prgcr-0c77b88 | 0 | 0 | 0 | 140 | 0.0 |
| greedy-lookahead-agent-953a054 | 0 | 0 | 0 | 140 | 0.0 |
| intelligentagent-a1bfe3c | 0 | 0 | 0 | 140 | 0.0 |
| my-awesome-agent-9c1133c | 0 | 0 | 0 | 140 | 0.0 |
| teamtitansagentv3-87cd5e2 | 0 | 0 | 0 | 140 | 0.0 |
| forward-thinkers-7583470 | 0 | 0 | 0 | 120 | 0.0 |
| hybridsmartagent2-85abfda | 0 | 0 | 0 | 120 | 0.0 |
| nanaboshi08271-5ea4531 | 0 | 0 | 0 | 100 | 0.0 |
| another-awesome-agent-9c1133c | 0 | 0 | 0 | 80 | 0.0 |
| gnn-vs-greedy-493cc7d | 0 | 0 | 0 | 80 | 0.0 |
| teamtitansagentv3-256baf2 | 0 | 0 | 0 | 80 | 0.0 |

**Overall Average (weighted by games): 0.0%**  —  **Total wins/games: 2/4640**
**Overall Average (unweighted): 0.0%**
_Seat split totals:_ **P1 wins:** 2 — **P2 wins:** 0

AVG=0.0
